package arthur2;

import javax.swing.SwingUtilities;

import arthur2.framework.engine;
import arthur2.framework.resources.loader;

public class Arthur2 {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				loader.load();
				engine.init();
				engine.start();
			}
		});
	}
}