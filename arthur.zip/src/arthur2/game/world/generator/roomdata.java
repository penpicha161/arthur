package arthur2.game.world.generator;

import java.awt.Graphics;
import java.util.HashSet;

import arthur2.framework.resources.resources;
import arthur2.framework.util.mathhelper;
import arthur2.game.world.tile;

public class roomdata {
    	private tile[][] tilesData;
	
	private HashSet<mathhelper.Direction> exits;
        
    	public roomdata(byte[][] tilesData, mathhelper.Direction... exits) {
		this.tilesData = new tile[tilesData.length][tilesData[0].length];
		for(int i=0;i<this.tilesData.length;i++) {
			for(int j=0;j<this.tilesData[i].length;j++) {
				this.tilesData[i][j] = new tile(tilesData[i][j], j, i, tilesData[i][j] == 1 || tilesData[i][j] == 2);
			}
		}
		this.exits = new HashSet<>();
		for(mathhelper.Direction direction : exits) {
			this.exits.add(direction);
		}
	}
	
	public void render(Graphics graphics) {
		for(int i=0;i<this.tilesData.length;i++) {
			for(int j=0;j<this.tilesData[i].length;j++) {
				graphics.drawImage(resources.TEXTURES.get(this.tilesData[i][j].getID()), j*tile.SIZE, i*tile.SIZE, tile.SIZE, tile.SIZE, null);
			}
		}
	}
	
	public HashSet<mathhelper.Direction> getExits() {
		return exits;
	}
	
	public tile getTileAt(int x, int y) {
		return tilesData[y][x];
	}
	
	public int getSizeY() {
		return tilesData.length;
	}
	
	public int getSizeX() {
		return tilesData[0].length;
	}
}

