package arthur2.game.world;

import java.awt.Graphics;
import java.util.ArrayList;

import arthur2.framework.resources.resources;
import arthur2.game.entt.slime;
import arthur2.game.entt.player;
import arthur2.game.world.generator.roomdata;

public class room {
    	private roomdata data;
	private ArrayList<feature> features;
	private ArrayList<slime> enemies;
	
	public room(roomdata data) {
		this.data = data;
		this.features = new ArrayList<>();
		this.enemies = new ArrayList<>();
	}
	
	public roomdata getData() {
		return data;
	}
	
	public void placeFeature(feature feature) {
		if(data.getTileAt(feature.x / tile.SIZE, feature.y / tile.SIZE).getID() == resources.FLOOR ||
			data.getTileAt(feature.x / tile.SIZE, feature.y / tile.SIZE).getID() == resources.GRASS_2 ||
			data.getTileAt(feature.x / tile.SIZE, feature.y / tile.SIZE).getID() == resources.TILE)
			this.features.add(feature);
		else
			this.placeFeature(new feature(feature));
	}
	
	public void featureInteraction(player Player) {
		for(int i=0;i<this.features.size();i++) {
			if(this.features.get(i).intersects(Player))
				this.features.remove(i);
		}
	}
	
	public ArrayList<slime> getEnemies() {
		return enemies;
	}
	
	public void spawnEnemy(slime enemy) {
		if(data.getTileAt(enemy.x / tile.SIZE, enemy.y / tile.SIZE).getID() == resources.FLOOR)
			this.enemies.add(enemy);
		else
			this.spawnEnemy(new slime(enemy));
	}
	
	public void render(Graphics graphics) {
		this.data.render(graphics);
		for(feature feature : features) {
			feature.render(graphics);
		}
		for(slime enemy : enemies) {
			enemy.render(graphics);
		}
	}
}
