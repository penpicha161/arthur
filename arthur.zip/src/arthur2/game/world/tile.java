package arthur2.game.world;

import java.awt.Rectangle;

public class tile extends Rectangle {

	private static final long serialVersionUID = 1L;
	
	public static final int SIZE = 50;
	
	private byte tileID;
	private boolean wall;
	
	public tile(byte id, int posXinRoom, int posYinRoom, boolean isWall) {
		super(posXinRoom * SIZE, posYinRoom * SIZE, SIZE, SIZE);
		this.tileID = id;
		this.wall = isWall;
	}
	
	public byte getID() {
		return tileID;
	}
	
	public boolean isWall() {
		return wall;
	}
}