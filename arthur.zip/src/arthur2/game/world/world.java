package arthur2.game.world;

import java.util.HashSet;

import arthur2.framework.gui.windowmanager;
import arthur2.framework.util.mathhelper;
import arthur2.game.init;
import arthur2.game.entt.Entity;
import arthur2.game.world.generator.levelgenerator;
import arthur2.game.world.world;
import arthur2.game.world.generator.roomdata;

public class world {

	private room[][] rooms;
	private int currentX;
	private int currentY;
	
	public world(HashSet<mathhelper.Direction>[][] roomsData) {
		this.rooms = new room[roomsData.length][roomsData[0].length];
		for(int i=0;i<levelgenerator.WORLD_SIZE;i++) {
			for(int j=0;j<levelgenerator.WORLD_SIZE;j++) {
				for(roomdata roomData : init.ROOMS) {
					if(roomData.getExits().equals(roomsData[i][j]))
						this.rooms[i][j] = new room(roomData);
				}
			}
		}
		this.currentX = 0;
		this.currentY = 0;
	}
	
	public room getRoom(int x, int y) {
		return rooms[x][y];
	}
	
	public room getRoom() {
		return rooms[currentX][currentY];
	}
	
	public room getRoomRandom() {
		return rooms[mathhelper.randomInt(levelgenerator.WORLD_SIZE)][mathhelper.randomInt(levelgenerator.WORLD_SIZE)];
	}
	
	public void changeRoom(Entity player) {
		if(player.getCenterX() < 0) {
			this.currentX--;
			player.setCenterX(windowmanager.WIDTH);
		}
		else if(player.getCenterX() > windowmanager.WIDTH) {
			this.currentX++;
			player.setCenterX(0);
		}
		else if(player.getCenterY() < 0) {
			this.currentY--;
			player.setCenterY(windowmanager.HEIGHT);
		}
		else if(player.getCenterY() > windowmanager.HEIGHT) {
			this.currentY++;
			player.setCenterY(0);
		}
	}
}
