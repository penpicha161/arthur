package arthur2.game.world;

import java.awt.Graphics;
import java.awt.Rectangle;

import arthur2.framework.resources.resources;
import arthur2.framework.util.FnInterface;
import arthur2.framework.util.mathhelper;

public class feature extends tile {

	private static final long serialVersionUID = 1L;

	private FnInterface action;
	
	public feature(byte id, FnInterface action) {
		super(id, mathhelper.randomInt(2, 14), mathhelper.randomInt(2, 7), false);
		this.action = action;
	}
	
	public feature(feature copy) {
		this(copy.getID(), copy.action);
	}

	@Override
	public boolean intersects(Rectangle r) {
		if(super.intersects(r)) {
			this.action.action();
			return true;
		}
		return false;
	}
	
	public void render(Graphics graphics) {
		graphics.drawImage(resources.TEXTURES.get(super.getID()), super.x, super.y, super.width, super.height, null);
	}
}