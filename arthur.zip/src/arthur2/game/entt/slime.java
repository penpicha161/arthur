/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arthur2.game.entt;

import arthur2.framework.util.mathhelper;

public class slime extends Entity {

	private static final long serialVersionUID = 1L;

	private player target;
	
	private int hp;
	
	public slime(byte id, int health, player target) {
		super(id, mathhelper.randomInt(2, 14), mathhelper.randomInt(2, 7));
		this.target = target;
		super.speed = 2;
		this.hp = health;
	}
	
	public slime(slime copy) {
		this(copy.getID(), copy.hp, copy.target);
	}

	@Override
	public void move() {
		super.move();
		float angCoeff = ((float) this.target.y - (float) super.y) / ((float) this.target.x - (float) super.x);
		if(angCoeff < 1 && angCoeff > -1) {
			if(this.target.x < super.x) {
				super.up = false;
				super.down = false;
				super.left = true;
				super.right = false;
			} else {
				super.up = false;
				super.down = false;
				super.left = false;
				super.right = true;
			}
		}
		else if(angCoeff > 1 || angCoeff < -1) {
			if(this.target.y < super.y) {
				super.up = true;
				super.down = false;
				super.left = false;
				super.right = false;
			} else {
				super.up = false;
				super.down = true;
				super.left = false;
				super.right = false;
			}
		}
		else {
			if(this.target.x < super.x) {
				super.left = true;
				super.right = false;
			} else {
				super.left = false;
				super.right = true;
			}
		}
	}
	
	@Override
	public void setMovingUp(boolean up) {
		return;
	}
	
	@Override
	public void setMovingDown(boolean down) {
		return;
	}
	
	@Override
	public void setMovingLeft(boolean left) {
		return;
	}
	
	@Override
	public void setMovingRight(boolean right) {
		return;
	}
	
	public int getHp() {
		return hp;
	}
	
	public void damage(int amount, mathhelper.Direction knockback) {
		this.hp -= amount;
		super.x += knockback.dirX * 120;
		super.y += knockback.dirY * 120;
	}
}
