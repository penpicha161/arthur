package arthur2.game.entt;
import arthur2.framework.gui.windowmanager;
import java.awt.Graphics;
import java.awt.Rectangle;

import arthur2.framework.resources.resources;
import arthur2.framework.util.mathhelper;
import arthur2.game.world.tile;
import java.awt.Color;
import java.awt.Font;
public class player extends Entity {

	private static final long serialVersionUID = 1L;

	private int hp;
	private int maxHp;
	private byte regenDelay;
	private int armor;
	private int gold;
	
	private byte attackTime;
	private byte damageTime;

    public player(byte id, int posXinRoom, int posYinRoom) {
        super(id, posXinRoom, posYinRoom);
    }
	
	public player() {
		super(resources.PLAYER, mathhelper.randomInt(2, 14), mathhelper.randomInt(2, 7));
		this.hp = 20;
		this.maxHp = 20;
		this.regenDelay = 0;
		this.armor = 0;
		this.gold = 0;
		this.attackTime = 0;
		this.damageTime = 0;
	}
	
	public void replaceRandomly() {
		super.x = mathhelper.randomInt(2, 14)*tile.SIZE;
		super.y = mathhelper.randomInt(2, 7)*tile.SIZE;
	}

	public int getHp() {
		return hp;
	}
	
	public int getMaxHp() {
		return maxHp;
	}
	
	public void instantHeal(int amount) {
		this.hp += amount;
		if(this.hp > this.maxHp) this.hp = this.maxHp;
	}
	
	public void regenerateHealth() {
		if(this.hp < this.maxHp) this.regenDelay++;
		else this.regenDelay = 0;
		
		if(this.regenDelay == 50) {
			this.regenDelay = 0;
		}
	}
	
	public int getArmor() {
		return armor;
	}
	
	public void addArmor(int amount) {
		this.armor += amount;
		if(this.armor > 75) this.armor = 75;
	}
	
	public int getGold() {
		return gold;
	}
	
	public void giveGold(int amount) {
		this.gold += amount;
	}
	
	@Override
	public void move() {
		if(this.attackTime == 0) {
			super.move();
			switch(super.facing) {
			case NORTH: super.entityID = resources.PLAYER_BACK; break;
			case SOUTH: super.entityID = resources.PLAYER; break;
			case WEST: super.entityID = resources.PLAYER_LEFT; break;
			case EAST: super.entityID = resources.PLAYER_RIGHT; break;
			}
		}
	}
	
	public void decreaseTime() {
		if(this.attackTime > 0) this.attackTime--;
		if(this.damageTime > 0) this.damageTime--;
	}
	
	public void attack() {
		if(this.attackTime == 0) this.attackTime = 30;
	}
	
	public Rectangle getAttackBox() {
		if(this.attackTime == 20) {
			switch(super.facing) {
			case NORTH:
				return new Rectangle(super.x, super.y - super.height, super.width, super.height);
			case SOUTH:
				return new Rectangle(super.x, super.y + super.height, super.width, super.height);
			case WEST:
				return new Rectangle(super.x - super.width, super.y, super.width, super.height);
			case EAST:
				return new Rectangle(super.x + super.width, super.y, super.width, super.height);
			default:
				break;
			}
		}
		return new Rectangle(0, 0, 0, 0);
	}
	
	@Override
	public void render(Graphics graphics) {
		if((up || down || left || right) && this.attackTime == 0) {
			super.animationDelay++;
			if(super.animationDelay == 70) {
				super.animationDelay = 0;
				super.animationFrame = (byte) (1 - super.animationFrame);
			}
		}
		graphics.drawImage(resources.TEXTURES.get(entityID + animationFrame), super.x, super.y, super.width, super.height, null);
                if(this.hp<=0){
                graphics.setColor(new Color(0, 0, 0));
		graphics.fillRect(0, 0, windowmanager.WIDTH, windowmanager.HEIGHT);
                graphics.setFont(new Font("Araial", Font.PLAIN, 32));
                graphics.setColor(Color.WHITE);
                graphics.drawString("GAME OVER",250,200);
                }
                if(this.gold>=10){
                graphics.setColor(new Color(225, 225, 225));
		graphics.fillRect(0, 0, windowmanager.WIDTH, windowmanager.HEIGHT);
                graphics.setFont(new Font("Araial", Font.PLAIN, 32));
                graphics.setColor(Color.BLACK);
                graphics.drawString("COMPLETE",315,200);
                graphics.drawString("SCORE =  "+gold,315, 100);
                }
        }
	public void damage(int amount) {
		if(this.damageTime == 0) {
			this.hp -= amount;
			this.damageTime = 50;
		}
	}
}

