
package arthur2.framework.util;

public interface FnInterface {
    public void action();
}
