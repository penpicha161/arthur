package arthur2.framework.resources;

import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.Rectangle2D;
import java.net.URL;
import javax.swing.ImageIcon;

public class loader {
    
public static void load() {
		try {
			File texturesFolder = new File("res/rooms");
			for(File imgFile : texturesFolder.listFiles()) {
					resources.ROOMS.put(imgFile.getName(), ImageIO.read(imgFile));
			}
			resources.TEXTURES.add(resources.FLOOR, ImageIO.read(new File("res/textures/floor.png")));
			resources.TEXTURES.add(resources.STONE, ImageIO.read(new File("res/textures/stone.png")));
			resources.TEXTURES.add(resources.WALL, ImageIO.read(new File("res/textures/wall.png")));
			resources.TEXTURES.add(resources.TILE, ImageIO.read(new File("res/textures/tile.png")));
			resources.TEXTURES.add(resources.GRASS, ImageIO.read(new File("res/textures/grass.png")));
			resources.TEXTURES.add(resources.PLAYER, ImageIO.read(new File("res/textures/player.png")));
			resources.TEXTURES.add(resources.PLAYER_2, ImageIO.read(new File("res/textures/player_2.png")));
			resources.TEXTURES.add(resources.PLAYER_LEFT, ImageIO.read(new File("res/textures/player_left.png")));
			resources.TEXTURES.add(resources.PLAYER_LEFT_2, ImageIO.read(new File("res/textures/player_left_2.png")));
			resources.TEXTURES.add(resources.PLAYER_RIGHT, ImageIO.read(new File("res/textures/player_right.png")));
			resources.TEXTURES.add(resources.PLAYER_RIGHT_2, ImageIO.read(new File("res/textures/player_right_2.png")));
			resources.TEXTURES.add(resources.PLAYER_BACK, ImageIO.read(new File("res/textures/player_back.png")));
			resources.TEXTURES.add(resources.PLAYER_BACK_2, ImageIO.read(new File("res/textures/player_back_2.png")));
			resources.TEXTURES.add(resources.STAIRS, ImageIO.read(new File("res/textures/stairs.png")));
			resources.TEXTURES.add(resources.CHEST, ImageIO.read(new File("res/textures/point2.png")));
			resources.TEXTURES.add(resources.ENEMY, ImageIO.read(new File("res/textures/enemy.png")));
			resources.TEXTURES.add(resources.ENEMY_2, ImageIO.read(new File("res/textures/enemy_2.png")));
			resources.TEXTURES.add(resources.ATTACK, ImageIO.read(new File("res/textures/attack.png")));
			resources.TEXTURES.add(resources.HEART, ImageIO.read(new File("res/textures/heart.png")));
			resources.TEXTURES.add(resources.ARMOR, ImageIO.read(new File("res/textures/armor.png")));
			resources.TEXTURES.add(resources.GOLD, ImageIO.read(new File("res/textures/point.png")));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}