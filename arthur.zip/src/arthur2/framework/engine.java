package arthur2.framework;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;
import javax.swing.Timer;

import arthur2.framework.gamestat.gamestatmanager;
import arthur2.framework.gui.windowmanager;
import arthur2.game.states.MainMenu;
public class engine {
    	private static gamestatmanager Gamestatmanager;
	
	private static windowmanager windowmanager;
	private static Timer timer;
	
	public static void init() {
		Gamestatmanager = new gamestatmanager();
		windowmanager = new windowmanager();
		timer = new Timer(20, new MainGameLoop());
	}
	
	public static void start() {
		Gamestatmanager.stackState(new MainMenu(Gamestatmanager));
		windowmanager.addPanel(new GameScreen());
		windowmanager.addKeyListener(new Keyboard());
		windowmanager.createWindow();
		timer.start();
	}
	
	private static class MainGameLoop implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			Gamestatmanager.loop();
		}
		
	}
	
	private static class GameScreen extends JPanel {
		
		private static final long serialVersionUID = 1L;

		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Gamestatmanager.render(g);
			repaint();
		}
	}
	
	private static class Keyboard implements KeyListener {

		@Override
		public void keyPressed(KeyEvent key) {
			Gamestatmanager.keyPressed(key.getKeyCode());
		}

		@Override
		public void keyReleased(KeyEvent key) {
			Gamestatmanager.keyReleased(key.getKeyCode());
		}

		@Override
		public void keyTyped(KeyEvent arg0) {}
		
	}
}
